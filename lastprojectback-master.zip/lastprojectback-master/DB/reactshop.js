const mysql = require('mysql2');

const reactshop = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'lastprogect'
});

reactshop.connect((err) => {
    if (err) {
        console.error('Error connecting to database:', err);
        return;
    }
    console.log('Connected to database successfully');
});

module.exports = reactshop;
